import { getRulesForDay } from "@/data/curriculum/month-01/day-rules";
import { createPracticeMeta } from "@/data/practice/shared";
import type { PracticeLesson } from "@/types/practice";

export const practiceDay01: PracticeLesson = {
  meta: { ...createPracticeMeta(1, "Đại từ nhân xưng (Pron)"), totalScreens: 7 },
  hints: {
    rules: getRulesForDay(1, ""),
    vocabulary: [
      { en: "I", vi: "tôi — người nói" },
      { en: "you", vi: "bạn / các bạn — người nghe" },
      { en: "he", vi: "anh ấy — một người nam" },
      { en: "she", vi: "cô ấy — một người nữ" },
      { en: "it", vi: "nó — đồ vật, con vật, sự việc" },
      { en: "we", vi: "chúng tôi / chúng ta" },
      { en: "they", vi: "họ / chúng" },
    ]
  },
  screens: [
    {
      type: "match",
      title: "Match the pronouns.\nNối đại từ (Pron).",
      instruction: "Match each pronoun with a picture. Tap the picture to see the Vietnamese meaning.\nNối đại từ (Pron) với ảnh. Bấm ảnh để xem nghĩa tiếng Việt.",
      words: [
        { id: "w-i", label: "I" },
        { id: "w-you", label: "you" },
        { id: "w-he", label: "he" },
        { id: "w-she", label: "she" },
        { id: "w-it", label: "it" },
        { id: "w-we", label: "we" },
        { id: "w-they", label: "they" },
      ],
      pairs: [
        { id: "p-i", imageUrl: "/images/practice/pronouns/i.jpg", imageAlt: "tôi — người nói", label: "tôi — người nói", correctWordId: "w-i" },
        { id: "p-you", imageUrl: "/images/practice/pronouns/you.jpg", imageAlt: "bạn / các bạn — người nghe", label: "bạn / các bạn — người nghe", correctWordId: "w-you" },
        { id: "p-he", imageUrl: "/images/practice/pronouns/he.jpg", imageAlt: "anh ấy — một người nam", label: "anh ấy — một người nam", correctWordId: "w-he" },
        { id: "p-she", imageUrl: "/images/practice/pronouns/she.jpg", imageAlt: "cô ấy — một người nữ", label: "cô ấy — một người nữ", correctWordId: "w-she" },
        { id: "p-it", imageUrl: "/images/practice/pronouns/it.jpg", imageAlt: "nó — đồ vật, con vật, sự việc", label: "nó — đồ vật, con vật, sự việc", correctWordId: "w-it" },
        { id: "p-we", imageUrl: "/images/practice/pronouns/we.jpg", imageAlt: "chúng tôi / chúng ta", label: "chúng tôi / chúng ta", correctWordId: "w-we" },
        { id: "p-they", imageUrl: "/images/practice/pronouns/they.jpg", imageAlt: "họ / chúng", label: "họ / chúng", correctWordId: "w-they" },
      ],
    },
    {
      type: "sentence-drag",
      title: "Fill in the pronoun.\nĐiền đại từ (Pron).",
      instruction: "Read who it is. Drag the pronoun into the blank.\nĐọc đó là ai. Kéo đại từ (Pron) vào chỗ trống.",
      wordBank: [
        { id: "s-i", label: "I" },
        { id: "s-he", label: "He" },
        { id: "s-she", label: "She" },
        { id: "s-it", label: "It" },
        { id: "s-we", label: "We" },
        { id: "s-they", label: "They" },
      ],
      sentences: [
        {
          id: "sent-1",
          parts: [
            { kind: "text", value: "Nam is my brother. " },
            { kind: "blank", id: "sd1", correctWordId: "s-he", width: "sm" },
            { kind: "text", value: " is 15 years old." },
          ],
        },
        {
          id: "sent-2",
          parts: [
            { kind: "text", value: "Lan is a teacher. " },
            { kind: "blank", id: "sd2", correctWordId: "s-she", width: "sm" },
            { kind: "text", value: " is kind." },
          ],
        },
        {
          id: "sent-3",
          parts: [
            { kind: "text", value: "My parents are at home. " },
            { kind: "blank", id: "sd3", correctWordId: "s-they", width: "sm" },
            { kind: "text", value: " are happy." },
          ],
        },
        {
          id: "sent-4",
          parts: [
            { kind: "text", value: "My cat is small. " },
            { kind: "blank", id: "sd4", correctWordId: "s-it", width: "sm" },
            { kind: "text", value: " is cute." },
          ],
        },
        {
          id: "sent-5",
          parts: [
            { kind: "text", value: "My friend and I are students. " },
            { kind: "blank", id: "sd5", correctWordId: "s-we", width: "sm" },
            { kind: "text", value: " are students." },
          ],
        },
        {
          id: "sent-6",
          parts: [
            { kind: "blank", id: "sd6", correctWordId: "s-i", width: "sm" },
            { kind: "text", value: " am a beginner in English." },
          ],
        },
      ],
    },
    {
      type: "dropdown",
      title: "Choose the correct pronoun.\nChọn đại từ (Pron) đúng.",
      instruction: "Choose the pronoun that replaces the name.\nChọn đại từ (Pron) thay cho tên hoặc cụm từ.",
      questions: [
        {
          id: "q1",
          parts: [
            { kind: "text", value: "Nam is a student. " },
            {
              kind: "select",
              id: "q1a",
              options: [
                { id: "q1a-he", label: "He" },
                { id: "q1a-she", label: "She" },
                { id: "q1a-it", label: "It" },
              ],
              correctOptionId: "q1a-he",
            },
            { kind: "text", value: " is a student." },
          ],
        },
        {
          id: "q2",
          parts: [
            { kind: "text", value: "Lan is my friend. " },
            {
              kind: "select",
              id: "q2a",
              options: [
                { id: "q2a-he", label: "He" },
                { id: "q2a-she", label: "She" },
                { id: "q2a-they", label: "They" },
              ],
              correctOptionId: "q2a-she",
            },
            { kind: "text", value: " is my friend." },
          ],
        },
        {
          id: "q3",
          parts: [
            { kind: "text", value: "The book is new. " },
            {
              kind: "select",
              id: "q3a",
              options: [
                { id: "q3a-he", label: "He" },
                { id: "q3a-it", label: "It" },
                { id: "q3a-we", label: "We" },
              ],
              correctOptionId: "q3a-it",
            },
            { kind: "text", value: " is new." },
          ],
        },
        {
          id: "q4",
          parts: [
            { kind: "text", value: "My brother and I are happy. " },
            {
              kind: "select",
              id: "q4a",
              options: [
                { id: "q4a-they", label: "They" },
                { id: "q4a-we", label: "We" },
                { id: "q4a-you", label: "You" },
              ],
              correctOptionId: "q4a-we",
            },
            { kind: "text", value: " are happy." },
          ],
        },
        { id: "q5", parts: [{ kind: "text", value: "My parents are kind. " }, { kind: "select", id: "q5a", correctOptionId: "q5-ok", options: [{ id: "q5-ok", label: "They" }, { id: "q5-no", label: "He" }, { id: "q5-no2", label: "She" }] }, { kind: "text", value: " are kind." }] },
        { id: "q6", parts: [{ kind: "text", value: "The cat is small. " }, { kind: "select", id: "q6a", correctOptionId: "q6-ok", options: [{ id: "q6-ok", label: "It" }, { id: "q6-no", label: "He" }, { id: "q6-no2", label: "They" }] }, { kind: "text", value: " is small." }] },
        { id: "q7", parts: [{ kind: "text", value: "Linh is a girl. " }, { kind: "select", id: "q7a", correctOptionId: "q7-ok", options: [{ id: "q7-ok", label: "She" }, { id: "q7-no", label: "He" }, { id: "q7-no2", label: "It" }] }, { kind: "text", value: " is a girl." }] },
        { id: "q8", parts: [{ kind: "text", value: "My brother is tall. " }, { kind: "select", id: "q8a", correctOptionId: "q8-ok", options: [{ id: "q8-ok", label: "He" }, { id: "q8-no", label: "She" }, { id: "q8-no2", label: "We" }] }, { kind: "text", value: " is tall." }] },
        { id: "q9", parts: [{ kind: "text", value: "You and I are friends. " }, { kind: "select", id: "q9a", correctOptionId: "q9-ok", options: [{ id: "q9-ok", label: "We" }, { id: "q9-no", label: "They" }, { id: "q9-no2", label: "You" }] }, { kind: "text", value: " are friends." }] },
        { id: "q10", parts: [{ kind: "text", value: "The students are here. " }, { kind: "select", id: "q10a", correctOptionId: "q10-ok", options: [{ id: "q10-ok", label: "They" }, { id: "q10-no", label: "We" }, { id: "q10-no2", label: "It" }] }, { kind: "text", value: " are here." }] },
      ],
    },
    {
      type: "reorder",
      layout: "horizontal",
      title: "Put the words in order.\nSắp xếp câu.",
      instruction: "Drag the words into a line.\nKéo các từ thành câu đúng.",
      sentences: [
        {
          id: "sen-1",
          label: "Câu 1",
          lines: [
            { id: "s1a", text: "He" },
            { id: "s1b", text: "is" },
            { id: "s1c", text: "a" },
            { id: "s1d", text: "student" },
          ],
          correctOrder: ["s1a", "s1b", "s1c", "s1d"],
        },
        {
          id: "sen-2",
          label: "Câu 2",
          lines: [
            { id: "s2a", text: "She" },
            { id: "s2b", text: "is" },
            { id: "s2c", text: "my" },
            { id: "s2d", text: "friend" },
          ],
          correctOrder: ["s2a", "s2b", "s2c", "s2d"],
        },
        {
          id: "sen-3",
          label: "Câu 3",
          lines: [
            { id: "s3a", text: "They" },
            { id: "s3b", text: "are" },
            { id: "s3c", text: "at" },
            { id: "s3d", text: "home" },
          ],
          correctOrder: ["s3a", "s3b", "s3c", "s3d"],
        },
        {
          id: "sen-4",
          label: "Câu 4",
          lines: [
            { id: "s4a", text: "We" },
            { id: "s4b", text: "are" },
            { id: "s4c", text: "happy" },
          ],
          correctOrder: ["s4a", "s4b", "s4c"],
        },
        {
          id: "sen-5",
          label: "Câu 5",
          lines: [
            { id: "s5a", text: "It" },
            { id: "s5b", text: "is" },
            { id: "s5c", text: "new" },
          ],
          correctOrder: ["s5a", "s5b", "s5c"],
        },
      ],
      lines: [],
      correctOrder: [],
    },
    {
      type: "reading-fill",
      title: "Read and fill in.\nĐọc và điền.",
      instruction: "Read the passage and type the pronoun in the blank on the same line.\nĐọc đoạn văn và điền đại từ (Pron) vào ô trên cùng một dòng.",
      passage:
        "Nam is a student. He is a student. Lan is my friend. She is my friend. My parents are at home. They are at home. The book is new. It is new.",
      prompts: [
        { id: "rf1", label: "Nam is a student. ___ is a student.", correctAnswers: ["He"] },
        { id: "rf2", label: "Lan is my friend. ___ is my friend.", correctAnswers: ["She"] },
        { id: "rf3", label: "My parents are at home. ___ are at home.", correctAnswers: ["They"] },
        { id: "rf4", label: "The book is new. ___ is new.", correctAnswers: ["It"] },
      ],
    },
    {
      type: "dictation",
      title: "Translate into English.\nDịch sang tiếng Anh.",
      instruction: "Read the Vietnamese sentence and write it in English. Press Check.\nĐọc câu tiếng Việt rồi viết câu tiếng Anh. Bấm Kiểm tra.",
      items: [
        { id: "dic-1", text: "She is my friend.", hint: "Cô ấy là bạn của tôi." },
        { id: "dic-2", text: "They are students.", hint: "Họ là học sinh." },
        { id: "dic-3", text: "We are happy.", hint: "Chúng tôi vui vẻ." },
        { id: "dic-4", text: "It is a book.", hint: "Nó là một quyển sách." },
        { id: "dic-5", text: "He is a student.", hint: "Anh ấy là học sinh." },
      ],
    },
    {
      type: "self-writing",
      title: "Write about you and your family.\nViết về bạn và gia đình.",
      instruction: "Write 4–5 sentences about you and your family. Use pronouns (I, he, she, we, they) and words from today: I, you, he, she, it.\nViết 4–5 câu về bạn và gia đình. Dùng đại từ (Pron) I, he, she, we, they và từ hôm nay (I, you, he, she, it, we, they).",
      promptHints: [
        "I am a student.",
        "My father is at work. He is busy.",
        "My mother is kind. She is at home.",
        "My sister and I are happy. We are students.",
        "My parents are tired. They are at home."
      ],
      sampleTitle: "Bài gợi ý",
      sample: "I am a student.\nMy father is at work. He is busy.\nMy mother is at home. She is kind.\nMy parents are happy. They love me.",
    },
  ],
};
