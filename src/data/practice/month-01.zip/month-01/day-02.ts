import { getRulesForDay } from "@/data/curriculum/month-01/day-rules";
import { createPracticeMeta } from "@/data/practice/shared";
import type { PracticeLesson } from "@/types/practice";

export const practiceDay02: PracticeLesson = {
  meta: { ...createPracticeMeta(2, "To be (V tobe): am, is, are"), totalScreens: 7 },
  hints: {
    rules: getRulesForDay(2, ""),
    vocabulary: [
      { en: "happy", vi: "vui vẻ" },
      { en: "sad", vi: "buồn" },
      { en: "tired", vi: "mệt" },
      { en: "busy", vi: "bận" },
      { en: "hungry", vi: "đói" },
      { en: "thirsty", vi: "khát" },
      { en: "ready", vi: "sẵn sàng" },
      { en: "fine", vi: "khỏe, ổn" },
    ]
  },
  screens: [
    {
      type: "match",
      title: "Match the words.\nNối từ.",
      instruction: "Match each word with a picture.\nNối từ với ảnh.",
      words: [
        { id: "w-happy", label: "happy" },
        { id: "w-sad", label: "sad" },
        { id: "w-tired", label: "tired" },
        { id: "w-busy", label: "busy" },
        { id: "w-hungry", label: "hungry" },
        { id: "w-thirsty", label: "thirsty" },
        { id: "w-ready", label: "ready" },
        { id: "w-fine", label: "fine" },
      ],
      pairs: [
        { id: "p-happy", imageUrl: "/images/practice/adjectives/happy.jpg", imageAlt: "vui vẻ", label: "vui vẻ", correctWordId: "w-happy" },
        { id: "p-sad", imageUrl: "/images/practice/adjectives/sad.jpg", imageAlt: "buồn", label: "buồn", correctWordId: "w-sad" },
        { id: "p-tired", imageUrl: "/images/practice/tobe/tired.jpg", imageAlt: "mệt", label: "mệt", correctWordId: "w-tired" },
        { id: "p-busy", imageUrl: "/images/practice/tobe/busy.jpg", imageAlt: "bận", label: "bận", correctWordId: "w-busy" },
        { id: "p-hungry", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "đói", label: "đói", correctWordId: "w-hungry" },
        { id: "p-thirsty", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "khát", label: "khát", correctWordId: "w-thirsty" },
        { id: "p-ready", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "sẵn sàng", label: "sẵn sàng", correctWordId: "w-ready" },
        { id: "p-fine", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "khỏe, ổn", label: "khỏe, ổn", correctWordId: "w-fine" },
      ],
    },
    {
      type: "sentence-drag",
      title: "Fill am, is, or are.\nĐiền am, is hoặc are.",
      instruction: "Drag am, is, or are into the blank.\nKéo am, is hoặc are vào chỗ trống.",
      wordBank: [
        { id: "s1", label: "am" },
        { id: "s2", label: "is" },
        { id: "s3", label: "are" },
        { id: "s4", label: "are" },
        { id: "s5", label: "is" },
      ],
      sentences: [
        { id: "sd1", parts: [{ kind: "text", value: "I " }, { kind: "blank", id: "b1", correctWordId: "s1" }, { kind: "text", value: " happy." }] },
        { id: "sd2", parts: [{ kind: "text", value: "She " }, { kind: "blank", id: "b2", correctWordId: "s2" }, { kind: "text", value: " a teacher." }] },
        { id: "sd3", parts: [{ kind: "text", value: "They " }, { kind: "blank", id: "b3", correctWordId: "s3" }, { kind: "text", value: " busy." }] },
        { id: "sd4", parts: [{ kind: "text", value: "We " }, { kind: "blank", id: "b4", correctWordId: "s4" }, { kind: "text", value: " ready." }] },
        { id: "sd5", parts: [{ kind: "text", value: "It " }, { kind: "blank", id: "b5", correctWordId: "s5" }, { kind: "text", value: " small." }] },
      ],
    },
    {
      type: "dropdown",
      title: "Choose am, is, or are.\nChọn am, is hoặc are.",
      instruction: "Choose the correct verb.\nChọn động từ (V) đúng.",
      questions: [
        { id: "q1", parts: [{ kind: "text", value: "He " }, { kind: "select", id: "q1a", correctOptionId: "q1-ok", options: [{ id: "q1-ok", label: "is" }, { id: "q1-no", label: "am" }, { id: "q1-no2", label: "are" }] }, { kind: "text", value: " tall." }] },
        { id: "q2", parts: [{ kind: "text", value: "We " }, { kind: "select", id: "q2a", correctOptionId: "q2-ok", options: [{ id: "q2-ok", label: "are" }, { id: "q2-no", label: "is" }, { id: "q2-no2", label: "am" }] }, { kind: "text", value: " students." }] },
        { id: "q3", parts: [{ kind: "text", value: "I " }, { kind: "select", id: "q3a", correctOptionId: "q3-ok", options: [{ id: "q3-ok", label: "am" }, { id: "q3-no", label: "is" }, { id: "q3-no2", label: "are" }] }, { kind: "text", value: " tired." }] },
        { id: "q4", parts: [{ kind: "text", value: "They " }, { kind: "select", id: "q4a", correctOptionId: "q4-ok", options: [{ id: "q4-ok", label: "are" }, { id: "q4-no", label: "is" }, { id: "q4-no2", label: "am" }] }, { kind: "text", value: " happy." }] },
        { id: "q5", parts: [{ kind: "text", value: "It " }, { kind: "select", id: "q5a", correctOptionId: "q5-ok", options: [{ id: "q5-ok", label: "is" }, { id: "q5-no", label: "are" }, { id: "q5-no2", label: "am" }] }, { kind: "text", value: " new." }] },
        { id: "q6", parts: [{ kind: "text", value: "She " }, { kind: "select", id: "q6a", correctOptionId: "q6-ok", options: [{ id: "q6-ok", label: "is" }, { id: "q6-no", label: "am" }, { id: "q6-no2", label: "are" }] }, { kind: "text", value: " my sister." }] },
        { id: "q7", parts: [{ kind: "text", value: "You " }, { kind: "select", id: "q7a", correctOptionId: "q7-ok", options: [{ id: "q7-ok", label: "are" }, { id: "q7-no", label: "is" }, { id: "q7-no2", label: "am" }] }, { kind: "text", value: " late." }] },
        { id: "q8", parts: [{ kind: "text", value: "Nam " }, { kind: "select", id: "q8a", correctOptionId: "q8-ok", options: [{ id: "q8-ok", label: "is" }, { id: "q8-no", label: "are" }, { id: "q8-no2", label: "am" }] }, { kind: "text", value: " busy." }] },
        { id: "q9", parts: [{ kind: "text", value: "My parents " }, { kind: "select", id: "q9a", correctOptionId: "q9-ok", options: [{ id: "q9-ok", label: "are" }, { id: "q9-no", label: "is" }, { id: "q9-no2", label: "am" }] }, { kind: "text", value: " at home." }] },
        { id: "q10", parts: [{ kind: "text", value: "The books " }, { kind: "select", id: "q10a", correctOptionId: "q10-ok", options: [{ id: "q10-ok", label: "are" }, { id: "q10-no", label: "is" }, { id: "q10-no2", label: "am" }] }, { kind: "text", value: " old." }] },
      ],
    },
    {
      type: "reorder",
      layout: "horizontal",
      title: "Order the sentence.\nSắp xếp câu.",
      instruction: "Drag the words into a line.\nKéo các từ thành câu đúng.",
      lines: [],
      correctOrder: [],
      sentences: [
        { id: "sen-1", label: "Câu 1", lines: [{ id: "s10", text: "I" }, { id: "s11", text: "am" }, { id: "s12", text: "happy" }], correctOrder: ["s10", "s11", "s12"] },
        { id: "sen-2", label: "Câu 2", lines: [{ id: "s20", text: "She" }, { id: "s21", text: "is" }, { id: "s22", text: "tired" }], correctOrder: ["s20", "s21", "s22"] },
        { id: "sen-3", label: "Câu 3", lines: [{ id: "s30", text: "They" }, { id: "s31", text: "are" }, { id: "s32", text: "busy" }], correctOrder: ["s30", "s31", "s32"] },
        { id: "sen-4", label: "Câu 4", lines: [{ id: "s40", text: "He" }, { id: "s41", text: "is" }, { id: "s42", text: "hungry" }], correctOrder: ["s40", "s41", "s42"] },
        { id: "sen-5", label: "Câu 5", lines: [{ id: "s50", text: "We" }, { id: "s51", text: "are" }, { id: "s52", text: "ready" }], correctOrder: ["s50", "s51", "s52"] },
      ],
    },
    {
      type: "reading-fill",
      title: "Fill the line.\nĐiền vào dòng.",
      instruction: "Type am, is, or are.\nGõ am, is hoặc are.",
      passage: "I am happy. She is tired. They are busy. We are ready. You are my friend. I am fine.",
      prompts: [
        { id: "rf1", label: "I ___ happy.", correctAnswers: ["am"] },
        { id: "rf2", label: "She ___ tired.", correctAnswers: ["is"] },
        { id: "rf3", label: "They ___ busy.", correctAnswers: ["are"] },
        { id: "rf4", label: "You ___ my friend.", correctAnswers: ["are"] },
        { id: "rf5", label: "I ___ fine.", correctAnswers: ["am"] },
      ],
    },
    {
      type: "dictation",
      title: "Translate into English.\nDịch sang tiếng Anh.",
      instruction: "Read the Vietnamese sentence and write it in English.\nĐọc câu tiếng Việt rồi viết câu tiếng Anh.",
      items: [
        { id: "dic-1", text: "I am happy.", hint: "Tôi vui." },
        { id: "dic-2", text: "She is tired.", hint: "Cô ấy mệt." },
        { id: "dic-3", text: "They are busy.", hint: "Họ bận." },
        { id: "dic-4", text: "He is hungry.", hint: "Anh ấy đói." },
        { id: "dic-5", text: "I am fine.", hint: "Tôi khỏe." },
      ],
    },
    {
      type: "self-writing",
      title: "Write about you and your family.\nViết về bạn và gia đình.",
      instruction: "Write 4 sentences with am, is, or are. Say how you and your family feel or are (happy, tired, busy, fine…). Use: happy, sad, tired, busy, hungry.\nViết 4 câu có am, is, are. Nói bạn và người thân thế nào (vui, mệt, bận…). Dùng từ: happy, sad, tired, fine, student, teacher.",
      promptHints: [
        "I am fine.",
        "My mother is tired.",
        "My father is busy.",
        "We are happy.",
        "They are at school."
      ],
      sampleTitle: "Bài gợi ý",
      sample: "I am fine.\nMy mother is tired.\nMy father is busy.\nWe are happy.",
    },
  ],
};
