import { getRulesForDay } from "@/data/curriculum/month-01/day-rules";
import { createPracticeMeta } from "@/data/practice/shared";
import type { PracticeLesson } from "@/types/practice";

export const practiceDay04: PracticeLesson = {
  meta: { ...createPracticeMeta(4, "Câu phủ định với to be (V tobe)"), totalScreens: 7 },
  hints: {
    rules: getRulesForDay(4, ""),
    vocabulary: [
      { en: "not", vi: "không" },
      { en: "isn't", vi: "không phải / không (số ít)" },
      { en: "aren't", vi: "không phải / không (số nhiều, you)" },
      { en: "late", vi: "muộn, trễ" },
      { en: "expensive", vi: "đắt" },
    ]
  },
  screens: [
    {
      type: "match",
      title: "Match the words.\nNối từ.",
      instruction: "Match each word with a picture.\nNối từ với ảnh.",
      words: [
        { id: "w-not", label: "not" },
        { id: "w-isn-t", label: "isn't" },
        { id: "w-aren-t", label: "aren't" },
        { id: "w-late", label: "late" },
        { id: "w-expensive", label: "expensive" },
      ],
      pairs: [
        { id: "p-not", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "không", label: "không", correctWordId: "w-not" },
        { id: "p-isn-t", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "không phải / không (số ít)", label: "không phải / không (số ít)", correctWordId: "w-isn-t" },
        { id: "p-aren-t", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "không phải / không (số nhiều, you)", label: "không phải / không (số nhiều, you)", correctWordId: "w-aren-t" },
        { id: "p-late", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "muộn, trễ", label: "muộn, trễ", correctWordId: "w-late" },
        { id: "p-expensive", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "đắt", label: "đắt", correctWordId: "w-expensive" },
      ],
    },
    {
      type: "dictation",
      title: "Make it negative.\nViết câu phủ định.",
      instruction: "Read the sentence. Write it with not. Use isn't or aren't when you can.\nĐọc câu khẳng định. Viết lại thành câu phủ định. Dùng isn't hoặc aren't nếu được.",
      promptLabel: "Câu khẳng định",
      inputPlaceholder: "Viết câu phủ định",
      doneMessage: "Bạn đã viết xong các câu phủ định. Bấm Tiếp.",
      items: [
        { id: "q-1", hint: "I am happy.", text: "I am not happy." },
        { id: "q-2", hint: "She is a student.", text: "She isn't a student." },
        { id: "q-3", hint: "He is tired.", text: "He isn't tired." },
        { id: "q-4", hint: "They are at school.", text: "They aren't at school." },
        { id: "q-5", hint: "We are busy.", text: "We aren't busy." },
      ],
    },
    {
      type: "dropdown",
      title: "Choose am not, isn't, or aren't.\nChọn am not, isn't hoặc aren't.",
      instruction: "Choose the negative form. Do not use don't.\nChọn dạng phủ định. Không dùng don't.",
      questions: [
        { id: "q1", parts: [{ kind: "text", value: "I " }, { kind: "select", id: "q1a", correctOptionId: "q1-ok", options: [{ id: "q1-ok", label: "am not" }, { id: "q1-no", label: "isn't" }, { id: "q1-no2", label: "don't" }] }, { kind: "text", value: " sad." }] },
        { id: "q2", parts: [{ kind: "text", value: "He " }, { kind: "select", id: "q2a", correctOptionId: "q2-ok", options: [{ id: "q2-ok", label: "isn't" }, { id: "q2-no", label: "aren't" }, { id: "q2-no2", label: "am not" }] }, { kind: "text", value: " my brother." }] },
        { id: "q3", parts: [{ kind: "text", value: "They " }, { kind: "select", id: "q3a", correctOptionId: "q3-ok", options: [{ id: "q3-ok", label: "aren't" }, { id: "q3-no", label: "isn't" }, { id: "q3-no2", label: "don't" }] }, { kind: "text", value: " at home." }] },
        { id: "q4", parts: [{ kind: "text", value: "It " }, { kind: "select", id: "q4a", correctOptionId: "q4-ok", options: [{ id: "q4-ok", label: "isn't" }, { id: "q4-no", label: "aren't" }, { id: "q4-no2", label: "am not" }] }, { kind: "text", value: " expensive." }] },
        { id: "q5", parts: [{ kind: "text", value: "She " }, { kind: "select", id: "q5a", correctOptionId: "q5-ok", options: [{ id: "q5-ok", label: "isn't" }, { id: "q5-no", label: "aren't" }, { id: "q5-no2", label: "am not" }] }, { kind: "text", value: " hungry." }] },
        { id: "q6", parts: [{ kind: "text", value: "We " }, { kind: "select", id: "q6a", correctOptionId: "q6-ok", options: [{ id: "q6-ok", label: "aren't" }, { id: "q6-no", label: "isn't" }, { id: "q6-no2", label: "am not" }] }, { kind: "text", value: " ready." }] },
        { id: "q7", parts: [{ kind: "text", value: "You " }, { kind: "select", id: "q7a", correctOptionId: "q7-ok", options: [{ id: "q7-ok", label: "aren't" }, { id: "q7-no", label: "isn't" }, { id: "q7-no2", label: "am not" }] }, { kind: "text", value: " late." }] },
        { id: "q8", parts: [{ kind: "text", value: "Nam " }, { kind: "select", id: "q8a", correctOptionId: "q8-ok", options: [{ id: "q8-ok", label: "isn't" }, { id: "q8-no", label: "aren't" }, { id: "q8-no2", label: "don't" }] }, { kind: "text", value: " at school." }] },
        { id: "q9", parts: [{ kind: "text", value: "My friends " }, { kind: "select", id: "q9a", correctOptionId: "q9-ok", options: [{ id: "q9-ok", label: "aren't" }, { id: "q9-no", label: "isn't" }, { id: "q9-no2", label: "am not" }] }, { kind: "text", value: " busy." }] },
        { id: "q10", parts: [{ kind: "text", value: "I " }, { kind: "select", id: "q10a", correctOptionId: "q10-ok", options: [{ id: "q10-ok", label: "am not" }, { id: "q10-no", label: "isn't" }, { id: "q10-no2", label: "aren't" }] }, { kind: "text", value: " a teacher." }] },
      ],
    },
    {
      type: "reorder",
      layout: "horizontal",
      title: "Order the sentence.\nSắp xếp câu.",
      instruction: "Drag the words into a line. not comes after am, is, or are.\nKéo các từ thành câu. not đứng sau am, is hoặc are.",
      lines: [],
      correctOrder: [],
      sentences: [
        { id: "sen-1", label: "Câu 1", lines: [{ id: "s10", text: "I" }, { id: "s11", text: "am" }, { id: "s12", text: "not" }, { id: "s13", text: "tired" }], correctOrder: ["s10", "s11", "s12", "s13"] },
        { id: "sen-2", label: "Câu 2", lines: [{ id: "s20", text: "He" }, { id: "s21", text: "isn't" }, { id: "s22", text: "a" }, { id: "s23", text: "teacher" }], correctOrder: ["s20", "s21", "s22", "s23"] },
        { id: "sen-3", label: "Câu 3", lines: [{ id: "s30", text: "She" }, { id: "s31", text: "isn't" }, { id: "s32", text: "at" }, { id: "s33", text: "home" }], correctOrder: ["s30", "s31", "s32", "s33"] },
        { id: "sen-4", label: "Câu 4", lines: [{ id: "s40", text: "We" }, { id: "s41", text: "aren't" }, { id: "s42", text: "busy" }], correctOrder: ["s40", "s41", "s42"] },
        { id: "sen-5", label: "Câu 5", lines: [{ id: "s50", text: "They" }, { id: "s51", text: "aren't" }, { id: "s52", text: "hungry" }], correctOrder: ["s50", "s51", "s52"] },
      ],
    },
    {
      type: "reading-fill",
      title: "Fill the line.\nĐiền vào dòng.",
      instruction: "Type am not, isn't, or aren't.\nGõ am not, isn't hoặc aren't.",
      passage: "I am not tired. He isn't a teacher. She isn't at home. We aren't busy. They aren't hungry.",
      prompts: [
        { id: "rf1", label: "I ___ tired.", correctAnswers: ["am not"] },
        { id: "rf2", label: "He ___ a teacher.", correctAnswers: ["isn't", "is not"] },
        { id: "rf3", label: "We ___ busy.", correctAnswers: ["aren't", "are not"] },
        { id: "rf4", label: "They ___ hungry.", correctAnswers: ["aren't", "are not"] },
      ],
    },
    {
      type: "sentence-drag",
      title: "Fill the negative.\nĐiền dạng phủ định.",
      instruction: "Drag am not, isn't, or aren't into the blank.\nKéo am not, isn't hoặc aren't vào chỗ trống.",
      wordBank: [
        { id: "s1", label: "am not" },
        { id: "s2", label: "isn't" },
        { id: "s3", label: "aren't" },
        { id: "s4", label: "isn't" },
      ],
      sentences: [
        { id: "sd1", parts: [{ kind: "text", value: "I " }, { kind: "blank", id: "b1", correctWordId: "s1", width: "md" }, { kind: "text", value: " sad." }] },
        { id: "sd2", parts: [{ kind: "text", value: "She " }, { kind: "blank", id: "b2", correctWordId: "s2" }, { kind: "text", value: " busy." }] },
        { id: "sd3", parts: [{ kind: "text", value: "We " }, { kind: "blank", id: "b3", correctWordId: "s3" }, { kind: "text", value: " tired." }] },
        { id: "sd4", parts: [{ kind: "text", value: "It " }, { kind: "blank", id: "b4", correctWordId: "s4" }, { kind: "text", value: " expensive." }] },
      ],
    },
    {
      type: "self-writing",
      title: "Write about you and your family.\nViết về bạn và gia đình.",
      instruction: "Write 4 sentences: 2 about you (I am not…), 2 about family with isn't / aren't.\nViết 4 câu: 2 về bạn (I am not…), 2 về người thân với isn't / aren't.",
      promptHints: [
        "I am not tired.",
        "I am not sad.",
        "My father isn't at home.",
        "My sisters aren't at school."
      ],
      sampleTitle: "Bài gợi ý",
      sample: "I am not tired.\nI am not angry.\nMy father isn't at home.\nMy friends aren't busy.",
    },
  ],
};
