import { getRulesForDay } from "@/data/curriculum/month-01/day-rules";
import { createPracticeMeta } from "@/data/practice/shared";
import type { PracticeLesson } from "@/types/practice";

export const practiceDay06: PracticeLesson = {
  meta: { ...createPracticeMeta(6, "Giới thiệu bản thân"), totalScreens: 7 },
  hints: {
    rules: getRulesForDay(6, ""),
    vocabulary: [
      { en: "name", vi: "tên" },
      { en: "years old", vi: "tuổi" },
      { en: "from", vi: "đến từ" },
      { en: "live", vi: "sống" },
      { en: "family", vi: "gia đình" },
      { en: "hobby", vi: "sở thích" },
      { en: "job", vi: "công việc" },
      { en: "friendly", vi: "thân thiện" },
    ]
  },
  screens: [
    {
      type: "match",
      title: "Match the words.\nNối từ.",
      instruction: "Match each word with a picture.\nNối từ với ảnh.",
      words: [
        { id: "w-name", label: "name" },
        { id: "w-years-old", label: "years old" },
        { id: "w-from", label: "from" },
        { id: "w-live", label: "live" },
        { id: "w-family", label: "family" },
        { id: "w-hobby", label: "hobby" },
        { id: "w-job", label: "job" },
        { id: "w-friendly", label: "friendly" },
      ],
      pairs: [
        { id: "p-name", imageUrl: "/images/practice/tobe/name.jpg", imageAlt: "tên", label: "tên", correctWordId: "w-name" },
        { id: "p-years-old", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "tuổi", label: "tuổi", correctWordId: "w-years-old" },
        { id: "p-from", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "đến từ", label: "đến từ", correctWordId: "w-from" },
        { id: "p-live", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "sống", label: "sống", correctWordId: "w-live" },
        { id: "p-family", imageUrl: "/images/practice/tobe/family.jpg", imageAlt: "gia đình", label: "gia đình", correctWordId: "w-family" },
        { id: "p-hobby", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "sở thích", label: "sở thích", correctWordId: "w-hobby" },
        { id: "p-job", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "công việc", label: "công việc", correctWordId: "w-job" },
        { id: "p-friendly", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "thân thiện", label: "thân thiện", correctWordId: "w-friendly" },
      ],
    },
    {
      type: "sentence-drag",
      title: "Fill the sentence.\nĐiền vào câu.",
      instruction: "Drag the word into the blank.\nKéo từ vào chỗ trống.",
      wordBank: [
        { id: "s1", label: "name" },
        { id: "s2", label: "old" },
        { id: "s3", label: "from" },
        { id: "s4", label: "live" },
        { id: "s5", label: "hobby" },
      ],
      sentences: [
        { id: "sd1", parts: [{ kind: "text", value: "My " }, { kind: "blank", id: "b1", correctWordId: "s1" }, { kind: "text", value: " is Nam." }] },
        { id: "sd2", parts: [{ kind: "text", value: "I am fifteen years " }, { kind: "blank", id: "b2", correctWordId: "s2" }, { kind: "text", value: "." }] },
        { id: "sd3", parts: [{ kind: "text", value: "I am " }, { kind: "blank", id: "b3", correctWordId: "s3" }, { kind: "text", value: " Vietnam." }] },
        { id: "sd4", parts: [{ kind: "text", value: "I " }, { kind: "blank", id: "b4", correctWordId: "s4" }, { kind: "text", value: " in Hanoi." }] },
        { id: "sd5", parts: [{ kind: "text", value: "My " }, { kind: "blank", id: "b5", correctWordId: "s5" }, { kind: "text", value: " is football." }] },
      ],
    },
    {
      type: "dropdown",
      title: "Choose the word.\nChọn từ đúng.",
      instruction: "Choose the word that completes the introduction.\nChọn từ để hoàn thành câu giới thiệu.",
      questions: [
        { id: "q1", parts: [{ kind: "text", value: "My name " }, { kind: "select", id: "q1a", correctOptionId: "q1-ok", options: [{ id: "q1-ok", label: "is" }, { id: "q1-no", label: "am" }, { id: "q1-no2", label: "are" }] }, { kind: "text", value: " Nam." }] },
        { id: "q2", parts: [{ kind: "text", value: "I am fifteen " }, { kind: "select", id: "q2a", correctOptionId: "q2-ok", options: [{ id: "q2-ok", label: "years old" }, { id: "q2-no", label: "year" }, { id: "q2-no2", label: "old years" }] }, { kind: "text", value: "." }] },
        { id: "q3", parts: [{ kind: "text", value: "I " }, { kind: "select", id: "q3a", correctOptionId: "q3-ok", options: [{ id: "q3-ok", label: "live" }, { id: "q3-no", label: "lives" }, { id: "q3-no2", label: "am live" }] }, { kind: "text", value: " in Hanoi." }] },
        { id: "q4", parts: [{ kind: "text", value: "My family " }, { kind: "select", id: "q4a", correctOptionId: "q4-ok", options: [{ id: "q4-ok", label: "is" }, { id: "q4-no", label: "am" }, { id: "q4-no2", label: "are" }] }, { kind: "text", value: " small." }] },
        { id: "q5", parts: [{ kind: "text", value: "I am " }, { kind: "select", id: "q5a", correctOptionId: "q5-ok", options: [{ id: "q5-ok", label: "from" }, { id: "q5-no", label: "live" }, { id: "q5-no2", label: "name" }] }, { kind: "text", value: " Vietnam." }] },
        { id: "q6", parts: [{ kind: "text", value: "My hobby " }, { kind: "select", id: "q6a", correctOptionId: "q6-ok", options: [{ id: "q6-ok", label: "is" }, { id: "q6-no", label: "am" }, { id: "q6-no2", label: "are" }] }, { kind: "text", value: " football." }] },
        { id: "q7", parts: [{ kind: "text", value: "I am a " }, { kind: "select", id: "q7a", correctOptionId: "q7-ok", options: [{ id: "q7-ok", label: "student" }, { id: "q7-no", label: "school" }, { id: "q7-no2", label: "Hanoi" }] }, { kind: "text", value: "." }] },
        { id: "q8", parts: [{ kind: "text", value: "I am fifteen years " }, { kind: "select", id: "q8a", correctOptionId: "q8-ok", options: [{ id: "q8-ok", label: "old" }, { id: "q8-no", label: "from" }, { id: "q8-no2", label: "live" }] }, { kind: "text", value: "." }] },
        { id: "q9", parts: [{ kind: "text", value: "We " }, { kind: "select", id: "q9a", correctOptionId: "q9-ok", options: [{ id: "q9-ok", label: "are" }, { id: "q9-no", label: "is" }, { id: "q9-no2", label: "am" }] }, { kind: "text", value: " friends." }] },
        { id: "q10", parts: [{ kind: "text", value: "She " }, { kind: "select", id: "q10a", correctOptionId: "q10-ok", options: [{ id: "q10-ok", label: "is" }, { id: "q10-no", label: "am" }, { id: "q10-no2", label: "are" }] }, { kind: "text", value: " my sister." }] },
      ],
    },
    {
      type: "reorder",
      layout: "horizontal",
      title: "Order the sentence.\nSắp xếp câu.",
      instruction: "Drag the words into a line.\nKéo các từ thành câu đúng.",
      lines: [],
      correctOrder: [],
      sentences: [
        { id: "sen-1", label: "Câu 1", lines: [{ id: "s10", text: "My" }, { id: "s11", text: "name" }, { id: "s12", text: "is" }, { id: "s13", text: "Nam" }], correctOrder: ["s10", "s11", "s12", "s13"] },
        { id: "sen-2", label: "Câu 2", lines: [{ id: "s20", text: "I" }, { id: "s21", text: "am" }, { id: "s22", text: "fifteen" }, { id: "s23", text: "years" }, { id: "s24", text: "old" }], correctOrder: ["s20", "s21", "s22", "s23", "s24"] },
        { id: "sen-3", label: "Câu 3", lines: [{ id: "s30", text: "I" }, { id: "s31", text: "am" }, { id: "s32", text: "from" }, { id: "s33", text: "Vietnam" }], correctOrder: ["s30", "s31", "s32", "s33"] },
        { id: "sen-4", label: "Câu 4", lines: [{ id: "s40", text: "I" }, { id: "s41", text: "live" }, { id: "s42", text: "in" }, { id: "s43", text: "Hanoi" }], correctOrder: ["s40", "s41", "s42", "s43"] },
        { id: "sen-5", label: "Câu 5", lines: [{ id: "s50", text: "My" }, { id: "s51", text: "hobby" }, { id: "s52", text: "is" }, { id: "s53", text: "football" }], correctOrder: ["s50", "s51", "s52", "s53"] },
      ],
    },
    {
      type: "reading-fill",
      title: "Fill the line.\nĐiền vào dòng.",
      instruction: "Type the missing word.\nGõ từ còn thiếu.",
      passage: "My name is Nam. I am fifteen years old. I am from Vietnam. I live in Hanoi. I am a student. My hobby is football.",
      prompts: [
        { id: "rf1", label: "My ___ is Nam.", correctAnswers: ["name"] },
        { id: "rf2", label: "I am fifteen years ___.", correctAnswers: ["old"] },
        { id: "rf3", label: "I am ___ Vietnam.", correctAnswers: ["from"] },
        { id: "rf4", label: "I ___ in Hanoi.", correctAnswers: ["live"] },
      ],
    },
    {
      type: "dictation",
      title: "Translate into English.\nDịch sang tiếng Anh.",
      instruction: "Read the Vietnamese sentence and write it in English.\nĐọc câu tiếng Việt rồi viết câu tiếng Anh.",
      items: [
        { id: "dic-1", text: "My name is Nam.", hint: "Tên tôi là Nam." },
        { id: "dic-2", text: "I am fifteen years old.", hint: "Tôi 15 tuổi." },
        { id: "dic-3", text: "I am from Vietnam.", hint: "Tôi đến từ Việt Nam." },
        { id: "dic-4", text: "I live in Hanoi.", hint: "Tôi sống ở Hà Nội." },
        { id: "dic-5", text: "My hobby is football.", hint: "Sở thích của tôi là bóng đá." },
      ],
    },
    {
      type: "self-writing",
      title: "Introduce yourself and your family.\nGiới thiệu bạn và gia đình.",
      instruction: "Write 4–5 sentences: your name, age, where you live, student, and one sentence about your family.\nViết 4–5 câu: tên, tuổi, nơi ở, học sinh, và một câu về gia đình.",
      promptHints: [
        "My name is Nam.",
        "I am 15 years old.",
        "I live in Hanoi.",
        "I am a student.",
        "I have a small family."
      ],
      sampleTitle: "Bài gợi ý",
      sample: "My name is Nam.\nI am 15 years old.\nI live in Hanoi with my family.\nI am a student.\nMy family is happy.",
    },
  ],
};
