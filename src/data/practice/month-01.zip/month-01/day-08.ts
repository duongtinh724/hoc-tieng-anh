import { getRulesForDay } from "@/data/curriculum/month-01/day-rules";
import { createPracticeMeta } from "@/data/practice/shared";
import type { PracticeLesson } from "@/types/practice";

export const practiceDay08: PracticeLesson = {
  meta: { ...createPracticeMeta(8, "Danh từ (N): người, vật, nơi"), totalScreens: 7 },
  hints: {
    rules: getRulesForDay(8, ""),
    vocabulary: [
      { en: "teacher", vi: "giáo viên" },
      { en: "student", vi: "học sinh" },
      { en: "doctor", vi: "bác sĩ" },
      { en: "book", vi: "quyển sách" },
      { en: "phone", vi: "điện thoại" },
      { en: "school", vi: "trường học" },
      { en: "hospital", vi: "bệnh viện" },
      { en: "park", vi: "công viên" },
    ]
  },
  screens: [
    {
      type: "match",
      title: "Match the nouns.\nNối danh từ (N).",
      instruction: "Match each noun with a picture.\nNối danh từ (N) với ảnh.",
      words: [
        { id: "w-teacher", label: "teacher" },
        { id: "w-student", label: "student" },
        { id: "w-doctor", label: "doctor" },
        { id: "w-book", label: "book" },
        { id: "w-phone", label: "phone" },
        { id: "w-school", label: "school" },
        { id: "w-hospital", label: "hospital" },
        { id: "w-park", label: "park" },
      ],
      pairs: [
        { id: "p-teacher", imageUrl: "/images/practice/nouns-photo/teacher.jpg", imageAlt: "giáo viên", label: "giáo viên", correctWordId: "w-teacher" },
        { id: "p-student", imageUrl: "/images/practice/nouns-photo/student.jpg", imageAlt: "học sinh", label: "học sinh", correctWordId: "w-student" },
        { id: "p-doctor", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "bác sĩ", label: "bác sĩ", correctWordId: "w-doctor" },
        { id: "p-book", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "quyển sách", label: "quyển sách", correctWordId: "w-book" },
        { id: "p-phone", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "điện thoại", label: "điện thoại", correctWordId: "w-phone" },
        { id: "p-school", imageUrl: "/images/practice/nouns-photo/school.jpg", imageAlt: "trường học", label: "trường học", correctWordId: "w-school" },
        { id: "p-hospital", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "bệnh viện", label: "bệnh viện", correctWordId: "w-hospital" },
        { id: "p-park", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "công viên", label: "công viên", correctWordId: "w-park" },
      ],
    },
    {
      type: "sentence-drag",
      title: "Fill the noun.\nĐiền danh từ (N).",
      instruction: "Drag the noun into the blank.\nKéo danh từ (N) vào chỗ trống.",
      wordBank: [
        { id: "s1", label: "book" },
        { id: "s2", label: "doctor" },
        { id: "s3", label: "student" },
        { id: "s4", label: "park" },
        { id: "s5", label: "school" },
      ],
      sentences: [
        { id: "sd1", parts: [{ kind: "text", value: "I read a " }, { kind: "blank", id: "b1", correctWordId: "s1" }, { kind: "text", value: "." }] },
        { id: "sd2", parts: [{ kind: "text", value: "He is a " }, { kind: "blank", id: "b2", correctWordId: "s2" }, { kind: "text", value: ". He works in a hospital." }] },
        { id: "sd3", parts: [{ kind: "text", value: "My sister is a " }, { kind: "blank", id: "b3", correctWordId: "s3" }, { kind: "text", value: "." }] },
        { id: "sd4", parts: [{ kind: "text", value: "The children are at the " }, { kind: "blank", id: "b4", correctWordId: "s4" }, { kind: "text", value: "." }] },
        { id: "sd5", parts: [{ kind: "text", value: "This is my " }, { kind: "blank", id: "b5", correctWordId: "s5" }, { kind: "text", value: "." }] },
      ],
    },
    {
      type: "dropdown",
      title: "Choose the noun.\nChọn danh từ (N).",
      instruction: "Choose the noun that fits the sentence.\nChọn danh từ (N) đúng với câu.",
      questions: [
        { id: "q1", parts: [{ kind: "text", value: "I am a " }, { kind: "select", id: "q1a", correctOptionId: "q1-ok", options: [{ id: "q1-ok", label: "student" }, { id: "q1-no", label: "school" }, { id: "q1-no2", label: "book" }] }, { kind: "text", value: "." }] },
        { id: "q2", parts: [{ kind: "text", value: "He is a " }, { kind: "select", id: "q2a", correctOptionId: "q2-ok", options: [{ id: "q2-ok", label: "doctor" }, { id: "q2-no", label: "hospital" }, { id: "q2-no2", label: "park" }] }, { kind: "text", value: "." }] },
        { id: "q3", parts: [{ kind: "text", value: "This is a " }, { kind: "select", id: "q3a", correctOptionId: "q3-ok", options: [{ id: "q3-ok", label: "book" }, { id: "q3-no", label: "teachers" }, { id: "q3-no2", label: "school" }] }, { kind: "text", value: "." }] },
        { id: "q4", parts: [{ kind: "text", value: "They are " }, { kind: "select", id: "q4a", correctOptionId: "q4-ok", options: [{ id: "q4-ok", label: "teachers" }, { id: "q4-no", label: "a teacher" }, { id: "q4-no2", label: "hospital" }] }, { kind: "text", value: "." }] },
        { id: "q5", parts: [{ kind: "text", value: "She is a " }, { kind: "select", id: "q5a", correctOptionId: "q5-ok", options: [{ id: "q5-ok", label: "teacher" }, { id: "q5-no", label: "school" }, { id: "q5-no2", label: "hospital" }] }, { kind: "text", value: "." }] },
        { id: "q6", parts: [{ kind: "text", value: "This is a " }, { kind: "select", id: "q6a", correctOptionId: "q6-ok", options: [{ id: "q6-ok", label: "pen" }, { id: "q6-no", label: "students" }, { id: "q6-no2", label: "park" }] }, { kind: "text", value: "." }] },
        { id: "q7", parts: [{ kind: "text", value: "We are " }, { kind: "select", id: "q7a", correctOptionId: "q7-ok", options: [{ id: "q7-ok", label: "students" }, { id: "q7-no", label: "a student" }, { id: "q7-no2", label: "school" }] }, { kind: "text", value: "." }] },
        { id: "q8", parts: [{ kind: "text", value: "The school is a " }, { kind: "select", id: "q8a", correctOptionId: "q8-ok", options: [{ id: "q8-ok", label: "place" }, { id: "q8-no", label: "person" }, { id: "q8-no2", label: "teacher" }] }, { kind: "text", value: "." }] },
        { id: "q9", parts: [{ kind: "text", value: "Nam is a " }, { kind: "select", id: "q9a", correctOptionId: "q9-ok", options: [{ id: "q9-ok", label: "boy" }, { id: "q9-no", label: "school" }, { id: "q9-no2", label: "hospital" }] }, { kind: "text", value: "." }] },
        { id: "q10", parts: [{ kind: "text", value: "These are " }, { kind: "select", id: "q10a", correctOptionId: "q10-ok", options: [{ id: "q10-ok", label: "books" }, { id: "q10-no", label: "a book" }, { id: "q10-no2", label: "hospital" }] }, { kind: "text", value: "." }] },
      ],
    },
    {
      type: "reorder",
      layout: "horizontal",
      title: "Order the sentence.\nSắp xếp câu.",
      instruction: "Drag the words into a line.\nKéo các từ thành câu đúng.",
      lines: [],
      correctOrder: [],
      sentences: [
        { id: "sen-1", label: "Câu 1", lines: [{ id: "s10", text: "I" }, { id: "s11", text: "am" }, { id: "s12", text: "a" }, { id: "s13", text: "student" }], correctOrder: ["s10", "s11", "s12", "s13"] },
        { id: "sen-2", label: "Câu 2", lines: [{ id: "s20", text: "He" }, { id: "s21", text: "is" }, { id: "s22", text: "a" }, { id: "s23", text: "doctor" }], correctOrder: ["s20", "s21", "s22", "s23"] },
        { id: "sen-3", label: "Câu 3", lines: [{ id: "s30", text: "They" }, { id: "s31", text: "are" }, { id: "s32", text: "teachers" }], correctOrder: ["s30", "s31", "s32"] },
        { id: "sen-4", label: "Câu 4", lines: [{ id: "s40", text: "This" }, { id: "s41", text: "is" }, { id: "s42", text: "a" }, { id: "s43", text: "book" }], correctOrder: ["s40", "s41", "s42", "s43"] },
        { id: "sen-5", label: "Câu 5", lines: [{ id: "s50", text: "This" }, { id: "s51", text: "is" }, { id: "s52", text: "my" }, { id: "s53", text: "school" }], correctOrder: ["s50", "s51", "s52", "s53"] },
      ],
    },
    {
      type: "reading-fill",
      title: "Fill the line.\nĐiền vào dòng.",
      instruction: "Type the noun.\nGõ danh từ (N) còn thiếu.",
      passage: "I am a student. He is a doctor. They are teachers. This is a book. This is my school.",
      prompts: [
        { id: "rf1", label: "I am a ___.", correctAnswers: ["student"] },
        { id: "rf2", label: "He is a ___.", correctAnswers: ["doctor"] },
        { id: "rf3", label: "This is a ___.", correctAnswers: ["book"] },
        { id: "rf4", label: "This is my ___.", correctAnswers: ["school"] },
      ],
    },
    {
      type: "dictation",
      title: "Translate into English.\nDịch sang tiếng Anh.",
      instruction: "Read the Vietnamese sentence and write it in English.\nĐọc câu tiếng Việt rồi viết câu tiếng Anh.",
      items: [
        { id: "dic-1", text: "I am a student.", hint: "Tôi là học sinh." },
        { id: "dic-2", text: "He is a doctor.", hint: "Anh ấy là bác sĩ." },
        { id: "dic-3", text: "This is a book.", hint: "Đây là một quyển sách." },
        { id: "dic-4", text: "They are teachers.", hint: "Họ là giáo viên." },
        { id: "dic-5", text: "This is my school.", hint: "Đây là trường của tôi." },
      ],
    },
    {
      type: "self-writing",
      title: "Describe your room and family.\nMô tả phòng và gia đình.",
      instruction: "Write 4 sentences about things at home and people. Use nouns: teacher, student, doctor, book, phone.\nViết 4 câu về đồ vật ở nhà và người. Dùng danh từ (N): book, pen, bag, school, house…",
      promptHints: [
        "This is my book.",
        "My bag is on the table.",
        "My father is a teacher.",
        "Our house is small."
      ],
      sampleTitle: "Bài gợi ý",
      sample: "This is my book.\nMy pen is in the bag.\nMy father works at a school.\nOur house is small.",
    },
  ],
};
