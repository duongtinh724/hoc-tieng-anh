import { getRulesForDay } from "@/data/curriculum/month-01/day-rules";
import { createPracticeMeta } from "@/data/practice/shared";
import type { PracticeLesson } from "@/types/practice";

export const practiceDay09: PracticeLesson = {
  meta: { ...createPracticeMeta(9, "Danh từ (N) số ít và số nhiều"), totalScreens: 7 },
  hints: {
    rules: getRulesForDay(9, ""),
    vocabulary: [
      { en: "book / books", vi: "một / nhiều sách" },
      { en: "bus / buses", vi: "xe buýt" },
      { en: "baby / babies", vi: "em bé" },
      { en: "child / children", vi: "trẻ em" },
      { en: "man / men", vi: "đàn ông" },
      { en: "woman / women", vi: "phụ nữ" },
      { en: "person / people", vi: "người / mọi người" },
    ]
  },
  screens: [
    {
      type: "match",
      title: "One or many?\nMột hay nhiều?",
      instruction: "Match the word with the picture.\nNối từ với ảnh.",
      words: [
        { id: "w-book-books", label: "book / books" },
        { id: "w-bus-buses", label: "bus / buses" },
        { id: "w-baby-babies", label: "baby / babies" },
        { id: "w-child-children", label: "child / children" },
        { id: "w-man-men", label: "man / men" },
        { id: "w-woman-women", label: "woman / women" },
        { id: "w-person-people", label: "person / people" },
      ],
      pairs: [
        { id: "p-book-books", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "một / nhiều sách", label: "một / nhiều sách", correctWordId: "w-book-books" },
        { id: "p-bus-buses", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "xe buýt", label: "xe buýt", correctWordId: "w-bus-buses" },
        { id: "p-baby-babies", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "em bé", label: "em bé", correctWordId: "w-baby-babies" },
        { id: "p-child-children", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "trẻ em", label: "trẻ em", correctWordId: "w-child-children" },
        { id: "p-man-men", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "đàn ông", label: "đàn ông", correctWordId: "w-man-men" },
        { id: "p-woman-women", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "phụ nữ", label: "phụ nữ", correctWordId: "w-woman-women" },
        { id: "p-person-people", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "người / mọi người", label: "người / mọi người", correctWordId: "w-person-people" },
      ],
    },
    {
      type: "dictation",
      title: "Write the plural.\nViết số nhiều.",
      instruction: "Read the singular noun. Write the plural.\nĐọc danh từ (N) số ít. Viết dạng số nhiều.",
      promptLabel: "Số ít",
      inputPlaceholder: "Viết số nhiều",
      doneMessage: "Bạn đã viết xong các dạng số nhiều. Bấm Tiếp.",
      items: [
        { id: "q-1", hint: "book", text: "books" },
        { id: "q-2", hint: "bus", text: "buses" },
        { id: "q-3", hint: "box", text: "boxes" },
        { id: "q-4", hint: "baby", text: "babies" },
        { id: "q-5", hint: "child", text: "children" },
        { id: "q-6", hint: "man", text: "men" },
        { id: "q-7", hint: "woman", text: "women" },
        { id: "q-8", hint: "person", text: "people" },
      ],
    },
    {
      type: "dropdown",
      title: "is or are?\nis hay are?",
      instruction: "A plural noun goes with are.\nDanh từ (N) số nhiều đi với are.",
      questions: [
        { id: "q1", parts: [{ kind: "text", value: "The book " }, { kind: "select", id: "q1a", correctOptionId: "q1-ok", options: [{ id: "q1-ok", label: "is" }, { id: "q1-no", label: "are" }] }, { kind: "text", value: " new." }] },
        { id: "q2", parts: [{ kind: "text", value: "The students " }, { kind: "select", id: "q2a", correctOptionId: "q2-ok", options: [{ id: "q2-ok", label: "are" }, { id: "q2-no", label: "is" }] }, { kind: "text", value: " happy." }] },
        { id: "q3", parts: [{ kind: "text", value: "The children " }, { kind: "select", id: "q3a", correctOptionId: "q3-ok", options: [{ id: "q3-ok", label: "are" }, { id: "q3-no", label: "is" }] }, { kind: "text", value: " at home." }] },
        { id: "q4", parts: [{ kind: "text", value: "My friend " }, { kind: "select", id: "q4a", correctOptionId: "q4-ok", options: [{ id: "q4-ok", label: "is" }, { id: "q4-no", label: "are" }] }, { kind: "text", value: " busy." }] },
        { id: "q5", parts: [{ kind: "text", value: "The buses " }, { kind: "select", id: "q5a", correctOptionId: "q5-ok", options: [{ id: "q5-ok", label: "are" }, { id: "q5-no", label: "is" }] }, { kind: "text", value: " full." }] },
        { id: "q6", parts: [{ kind: "text", value: "The boxes " }, { kind: "select", id: "q6a", correctOptionId: "q6-ok", options: [{ id: "q6-ok", label: "are" }, { id: "q6-no", label: "is" }] }, { kind: "text", value: " heavy." }] },
        { id: "q7", parts: [{ kind: "text", value: "One baby " }, { kind: "select", id: "q7a", correctOptionId: "q7-ok", options: [{ id: "q7-ok", label: "is" }, { id: "q7-no", label: "are" }] }, { kind: "text", value: " here." }] },
        { id: "q8", parts: [{ kind: "text", value: "The men " }, { kind: "select", id: "q8a", correctOptionId: "q8-ok", options: [{ id: "q8-ok", label: "are" }, { id: "q8-no", label: "is" }] }, { kind: "text", value: " tall." }] },
        { id: "q9", parts: [{ kind: "text", value: "The woman " }, { kind: "select", id: "q9a", correctOptionId: "q9-ok", options: [{ id: "q9-ok", label: "is" }, { id: "q9-no", label: "are" }] }, { kind: "text", value: " a teacher." }] },
        { id: "q10", parts: [{ kind: "text", value: "The people " }, { kind: "select", id: "q10a", correctOptionId: "q10-ok", options: [{ id: "q10-ok", label: "are" }, { id: "q10-no", label: "is" }] }, { kind: "text", value: " kind." }] },
      ],
    },
    {
      type: "reorder",
      layout: "horizontal",
      title: "Order the plural sentence.\nSắp xếp câu số nhiều.",
      instruction: "Drag the words into a line.\nKéo các từ thành câu đúng.",
      lines: [],
      correctOrder: [],
      sentences: [
        { id: "sen-1", label: "Câu 1", lines: [{ id: "s10", text: "The" }, { id: "s11", text: "books" }, { id: "s12", text: "are" }, { id: "s13", text: "old" }], correctOrder: ["s10", "s11", "s12", "s13"] },
        { id: "sen-2", label: "Câu 2", lines: [{ id: "s20", text: "The" }, { id: "s21", text: "students" }, { id: "s22", text: "are" }, { id: "s23", text: "tall" }], correctOrder: ["s20", "s21", "s22", "s23"] },
        { id: "sen-3", label: "Câu 3", lines: [{ id: "s30", text: "The" }, { id: "s31", text: "cars" }, { id: "s32", text: "are" }, { id: "s33", text: "new" }], correctOrder: ["s30", "s31", "s32", "s33"] },
        { id: "sen-4", label: "Câu 4", lines: [{ id: "s40", text: "The" }, { id: "s41", text: "children" }, { id: "s42", text: "are" }, { id: "s43", text: "here" }], correctOrder: ["s40", "s41", "s42", "s43"] },
        { id: "sen-5", label: "Câu 5", lines: [{ id: "s50", text: "The" }, { id: "s51", text: "book" }, { id: "s52", text: "is" }, { id: "s53", text: "new" }], correctOrder: ["s50", "s51", "s52", "s53"] },
      ],
    },
    {
      type: "reading-fill",
      title: "Fill the line.\nĐiền vào dòng.",
      instruction: "Type is or are.\nGõ is hoặc are.",
      passage: "The book is new. The books are new. The child is here. The children are here.",
      prompts: [
        { id: "rf1", label: "The book ___ new.", correctAnswers: ["is"] },
        { id: "rf2", label: "The books ___ new.", correctAnswers: ["are"] },
        { id: "rf3", label: "The child ___ here.", correctAnswers: ["is"] },
        { id: "rf4", label: "The children ___ here.", correctAnswers: ["are"] },
      ],
    },
    {
      type: "sentence-drag",
      title: "Change to plural.\nĐổi sang số nhiều.",
      instruction: "Drag the plural noun into the blank.\nKéo danh từ (N) số nhiều vào chỗ trống.",
      wordBank: [
        { id: "s1", label: "books" },
        { id: "s2", label: "students" },
        { id: "s3", label: "cars" },
        { id: "s4", label: "children" },
      ],
      sentences: [
        { id: "sd1", parts: [{ kind: "text", value: "The " }, { kind: "blank", id: "b1", correctWordId: "s1" }, { kind: "text", value: " are old." }] },
        { id: "sd2", parts: [{ kind: "text", value: "The " }, { kind: "blank", id: "b2", correctWordId: "s2" }, { kind: "text", value: " are tall." }] },
        { id: "sd3", parts: [{ kind: "text", value: "The " }, { kind: "blank", id: "b3", correctWordId: "s3" }, { kind: "text", value: " are new." }] },
        { id: "sd4", parts: [{ kind: "text", value: "The " }, { kind: "blank", id: "b4", correctWordId: "s4" }, { kind: "text", value: " are here." }] },
      ],
    },
    {
      type: "self-writing",
      title: "Count things at home.\nĐếm đồ ở nhà.",
      instruction: "Write 4 sentences with singular and plural nouns about your family’s things.\nViết 4 câu có danh từ số ít và số nhiều về đồ của gia đình.",
      promptHints: [
        "I have one book.",
        "We have two pens.",
        "My parents have three bags.",
        "The students are in class."
      ],
      sampleTitle: "Bài gợi ý",
      sample: "I have one book.\nWe have two pens.\nMy books are new.\nThe students are happy.",
    },
  ],
};
