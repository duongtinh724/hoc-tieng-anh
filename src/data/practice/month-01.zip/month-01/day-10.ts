import { getRulesForDay } from "@/data/curriculum/month-01/day-rules";
import { createPracticeMeta } from "@/data/practice/shared";
import type { PracticeLesson } from "@/types/practice";

export const practiceDay10: PracticeLesson = {
  meta: { ...createPracticeMeta(10, "Mạo từ (Art) a / an"), totalScreens: 7 },
  hints: {
    rules: getRulesForDay(10, ""),
    vocabulary: [
      { en: "apple", vi: "quả táo" },
      { en: "egg", vi: "quả trứng" },
      { en: "orange", vi: "quả cam" },
      { en: "umbrella", vi: "cái ô" },
      { en: "hour", vi: "giờ" },
      { en: "university", vi: "trường đại học" },
      { en: "car", vi: "ô tô" },
      { en: "engineer", vi: "kỹ sư" },
    ]
  },
  screens: [
    {
      type: "match",
      title: "Match the words.\nNối từ.",
      instruction: "Match each word with a picture.\nNối từ với ảnh.",
      words: [
        { id: "w-apple", label: "apple" },
        { id: "w-egg", label: "egg" },
        { id: "w-orange", label: "orange" },
        { id: "w-umbrella", label: "umbrella" },
        { id: "w-hour", label: "hour" },
        { id: "w-university", label: "university" },
        { id: "w-car", label: "car" },
        { id: "w-engineer", label: "engineer" },
      ],
      pairs: [
        { id: "p-apple", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "quả táo", label: "quả táo", correctWordId: "w-apple" },
        { id: "p-egg", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "quả trứng", label: "quả trứng", correctWordId: "w-egg" },
        { id: "p-orange", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "quả cam", label: "quả cam", correctWordId: "w-orange" },
        { id: "p-umbrella", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "cái ô", label: "cái ô", correctWordId: "w-umbrella" },
        { id: "p-hour", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "giờ", label: "giờ", correctWordId: "w-hour" },
        { id: "p-university", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "trường đại học", label: "trường đại học", correctWordId: "w-university" },
        { id: "p-car", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "ô tô", label: "ô tô", correctWordId: "w-car" },
        { id: "p-engineer", imageUrl: "/images/practice/nouns-photo/book.jpg", imageAlt: "kỹ sư", label: "kỹ sư", correctWordId: "w-engineer" },
      ],
    },
    {
      type: "sentence-drag",
      title: "Fill a or an.\nĐiền a hoặc an.",
      instruction: "Drag a or an into the blank.\nKéo a hoặc an vào chỗ trống.",
      wordBank: [
        { id: "s1", label: "an" },
        { id: "s2", label: "a" },
        { id: "s3", label: "an" },
        { id: "s4", label: "a" },
        { id: "s5", label: "an" },
      ],
      sentences: [
        { id: "sd1", parts: [{ kind: "blank", id: "b1", correctWordId: "s1", width: "sm" }, { kind: "text", value: " apple" }] },
        { id: "sd2", parts: [{ kind: "blank", id: "b2", correctWordId: "s2", width: "sm" }, { kind: "text", value: " book" }] },
        { id: "sd3", parts: [{ kind: "blank", id: "b3", correctWordId: "s3", width: "sm" }, { kind: "text", value: " egg" }] },
        { id: "sd4", parts: [{ kind: "blank", id: "b4", correctWordId: "s4", width: "sm" }, { kind: "text", value: " university" }] },
        { id: "sd5", parts: [{ kind: "blank", id: "b5", correctWordId: "s5", width: "sm" }, { kind: "text", value: " hour" }] },
      ],
    },
    {
      type: "dropdown",
      title: "Choose a or an.\nChọn a hoặc an.",
      instruction: "Choose a or an. Look at the first sound.\nChọn a hoặc an. Nhìn âm đầu tiên.",
      questions: [
        { id: "q1", parts: [{ kind: "text", value: "I am " }, { kind: "select", id: "q1a", correctOptionId: "q1-ok", options: [{ id: "q1-ok", label: "a" }, { id: "q1-no", label: "an" }] }, { kind: "text", value: " student." }] },
        { id: "q2", parts: [{ kind: "text", value: "She is " }, { kind: "select", id: "q2a", correctOptionId: "q2-ok", options: [{ id: "q2-ok", label: "a" }, { id: "q2-no", label: "an" }] }, { kind: "text", value: " teacher." }] },
        { id: "q3", parts: [{ kind: "text", value: "He is " }, { kind: "select", id: "q3a", correctOptionId: "q3-ok", options: [{ id: "q3-ok", label: "an" }, { id: "q3-no", label: "a" }] }, { kind: "text", value: " engineer." }] },
        { id: "q4", parts: [{ kind: "text", value: "This is " }, { kind: "select", id: "q4a", correctOptionId: "q4-ok", options: [{ id: "q4-ok", label: "an" }, { id: "q4-no", label: "a" }] }, { kind: "text", value: " apple." }] },
        { id: "q5", parts: [{ kind: "text", value: "This is " }, { kind: "select", id: "q5a", correctOptionId: "q5-ok", options: [{ id: "q5-ok", label: "an" }, { id: "q5-no", label: "a" }] }, { kind: "text", value: " umbrella." }] },
        { id: "q6", parts: [{ kind: "text", value: "This is " }, { kind: "select", id: "q6a", correctOptionId: "q6-ok", options: [{ id: "q6-ok", label: "an" }, { id: "q6-no", label: "a" }] }, { kind: "text", value: " egg." }] },
        { id: "q7", parts: [{ kind: "text", value: "This is " }, { kind: "select", id: "q7a", correctOptionId: "q7-ok", options: [{ id: "q7-ok", label: "an" }, { id: "q7-no", label: "a" }] }, { kind: "text", value: " orange." }] },
        { id: "q8", parts: [{ kind: "text", value: "This is " }, { kind: "select", id: "q8a", correctOptionId: "q8-ok", options: [{ id: "q8-ok", label: "an" }, { id: "q8-no", label: "a" }] }, { kind: "text", value: " hour." }] },
        { id: "q9", parts: [{ kind: "text", value: "He is " }, { kind: "select", id: "q9a", correctOptionId: "q9-ok", options: [{ id: "q9-ok", label: "a" }, { id: "q9-no", label: "an" }] }, { kind: "text", value: " doctor." }] },
        { id: "q10", parts: [{ kind: "text", value: "It is " }, { kind: "select", id: "q10a", correctOptionId: "q10-ok", options: [{ id: "q10-ok", label: "a" }, { id: "q10-no", label: "an" }] }, { kind: "text", value: " university." }] },
      ],
    },
    {
      type: "reorder",
      layout: "horizontal",
      title: "Order the sentence.\nSắp xếp câu.",
      instruction: "Drag the words into a line.\nKéo các từ thành câu đúng.",
      lines: [],
      correctOrder: [],
      sentences: [
        { id: "sen-1", label: "Câu 1", lines: [{ id: "s10", text: "I" }, { id: "s11", text: "am" }, { id: "s12", text: "a" }, { id: "s13", text: "student" }], correctOrder: ["s10", "s11", "s12", "s13"] },
        { id: "sen-2", label: "Câu 2", lines: [{ id: "s20", text: "This" }, { id: "s21", text: "is" }, { id: "s22", text: "an" }, { id: "s23", text: "apple" }], correctOrder: ["s20", "s21", "s22", "s23"] },
        { id: "sen-3", label: "Câu 3", lines: [{ id: "s30", text: "He" }, { id: "s31", text: "is" }, { id: "s32", text: "an" }, { id: "s33", text: "engineer" }], correctOrder: ["s30", "s31", "s32", "s33"] },
        { id: "sen-4", label: "Câu 4", lines: [{ id: "s40", text: "This" }, { id: "s41", text: "is" }, { id: "s42", text: "an" }, { id: "s43", text: "umbrella" }], correctOrder: ["s40", "s41", "s42", "s43"] },
        { id: "sen-5", label: "Câu 5", lines: [{ id: "s50", text: "This" }, { id: "s51", text: "is" }, { id: "s52", text: "an" }, { id: "s53", text: "orange" }], correctOrder: ["s50", "s51", "s52", "s53"] },
      ],
    },
    {
      type: "reading-fill",
      title: "Fill a or an.\nĐiền a hoặc an.",
      instruction: "Type a or an.\nGõ a hoặc an.",
      passage: "I am a student. This is an apple. He is an engineer. This is an umbrella. It is a book.",
      prompts: [
        { id: "rf1", label: "I am ___ student.", correctAnswers: ["a"] },
        { id: "rf2", label: "This is ___ apple.", correctAnswers: ["an"] },
        { id: "rf3", label: "He is ___ engineer.", correctAnswers: ["an"] },
        { id: "rf4", label: "This is ___ umbrella.", correctAnswers: ["an"] },
        { id: "rf5", label: "It is ___ book.", correctAnswers: ["a"] },
      ],
    },
    {
      type: "dictation",
      title: "Fix the sentence.\nSửa câu.",
      instruction: "Read the wrong sentence. Write the correct sentence.\nĐọc câu sai. Viết lại câu đúng.",
      promptLabel: "Câu sai",
      inputPlaceholder: "Viết câu đúng",
      doneMessage: "Bạn đã sửa xong. Bấm Tiếp.",
      items: [
        { id: "dic-1", hint: "I am student.", text: "I am a student." },
        { id: "dic-2", hint: "She is an teacher.", text: "She is a teacher." },
        { id: "dic-3", hint: "He is a engineer.", text: "He is an engineer." },
        { id: "dic-4", hint: "This is an book.", text: "This is a book." },
        { id: "dic-5", hint: "It is a apple.", text: "It is an apple." },
      ],
    },
    {
      type: "self-writing",
      title: "Describe your things.\nMô tả đồ của bạn.",
      instruction: "Write 4 sentences with a / an about things you or your family have.\nViết 4 câu có a / an về đồ bạn hoặc gia đình có.",
      promptHints: [
        "I have a bag.",
        "She has an apple.",
        "He is a student.",
        "This is a book."
      ],
      sampleTitle: "Bài gợi ý",
      sample: "I have a bag.\nMy sister has an eraser.\nMy father is a teacher.\nThis is a pen.",
    },
  ],
};
